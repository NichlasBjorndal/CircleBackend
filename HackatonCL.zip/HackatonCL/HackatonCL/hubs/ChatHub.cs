﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;

namespace HackatonCL.hubs
{
    public class ChatHub : Hub
    {
        public async Task SendMessage(string message)
        {
            await Clients.Client(Context.ConnectionId).SendAsync("ReceiveMessage", Context.ConnectionId, message);
            
            await Clients.All.SendAsync("ReceiveMessage", Context.ConnectionId, message);

        }

        public async Task SendMessageToGroup(string message, string roomname)
        {
           await Clients.Group(groupName: roomname).SendAsync(message);
        }

        public async Task SendMessageTouser(string message, string userid)
        {
           await Clients.Client(connectionId: userid).SendAsync(message);
        }

        public Task JoinRoom(string roomname)
        {
            return Groups.AddToGroupAsync(Context.ConnectionId, roomname);
        }

        public Task LeaveRoom(string roomName)
        {
            return Groups.RemoveFromGroupAsync(Context.ConnectionId, roomName);
        }

    }
}
