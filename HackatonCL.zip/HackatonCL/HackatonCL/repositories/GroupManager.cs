﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HackatonCL.repositories
{
    public class GroupManager
    {

        //if this wasent a hackathon i would jump off of the 6th floor
        public Dictionary<string, List<string>> _groups = new Dictionary<string, List<string>>();
        
        

    }
}
